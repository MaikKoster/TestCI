﻿## PRIVATE MODULE FUNCTIONS AND DATA ##

function Get-CMSession {
    <#
    .SYNOPSIS
        Returns a valid session to the specified computer

    .DESCRIPTION
        Returns a valid session to the specified computer
        If session does not exist, new session is created
        Falls back from WSMAN to DCOM for backwards compatibility

    .EXAMPLE


    .NOTES
    #>
    [CmdLetBinding()]
    PARAM (
        # Specifies the ComputerName to connect to.
        [Parameter(Position=0)]
        [ValidateNotNullOrEmpty()]
        [string]$ComputerName = $env:COMPUTERNAME,

        # Specifies the credentials to connect to the Provider Server.
        [PSCredential]
        [System.Management.Automation.Credential()]$Credential = [System.Management.Automation.PSCredential]::Empty
    )

    Begin {

        $Opt = New-CimSessionOption -Protocol Dcom

        $SessionParams = @{
            ErrorAction = 'Stop'
        }

        if ($PSBoundParameters['Credential']) {
            $SessionParams.Credential = $Credential
        }
    }

    Process {
        # Check if there is an already existing session to the specified computer
        $Session = Get-CimSession | Where-Object { $_.ComputerName -eq $ComputerName} | Select-Object -First 1

        If ($null -eq $Session) {

            $SessionParams.ComputerName = $ComputerName

            $WSMan = Test-WSMan -ComputerName $ComputerName -ErrorAction SilentlyContinue

            If (($null -ne $WSMan) -and ($WSMan.ProductVersion -match 'Stack: ([3-9]|[1-9][0-9]+)\.[0-9]+')) {
                Try {
                    Write-Verbose -Message "Attempt to connect to $ComputerName using the WSMAN protocol."
                    $Session = New-CimSession @SessionParams
                } Catch {
                    Write-Verbose "Unable to connect to $ComputerName using the WSMAN protocol. Test DCOM ..."

                }
            }

            If ($null -eq $Session) {
                $SessionParams.SessionOption = $Opt

                Try {
                    Write-Verbose -Message "Attempt to connect to $ComputerName using the DCOM protocol."
                    $Session = New-CimSession @SessionParams
                } Catch {
                    Write-Error -Message "Unable to connect to $ComputerName using the WSMAN or DCOM protocol. Verify $ComputerName is online or credentials and try again."
                }
            }

            If ($null -eq $Session) {
                $Session = Get-CimSession | Where-Object { $_.ComputerName -eq $ComputerName} | Select-Object -First 1
            }
        }

        Return $Session
    }
}

function Get-WQLFilterString {
    <#
    .SYNOPSIS
        Gets a WQL filter string.

    .DESCRIPTION
        Uses the supplied values to generate a WQL search filter string that can be used for WMI.

    .EXAMPLE
        Get-WQLFilterString


    .NOTES

    #>
    [CmdLetBinding()]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseShouldProcessForStateChangingFunctions", "")]
    [Outputtype([string])]
    PARAM (
        [Parameter(Mandatory, ParameterSetName="Name", ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias("Name")]
        [string]$PropertyName,

        [Parameter(Mandatory, ParameterSetName="Name", ValueFromPipeline,ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias("Value")]
        [string[]]$PropertyValue,

        [Parameter(ParameterSetName="Name")]
        [switch]$Search,

        [Parameter(Mandatory, ParameterSetName="Or")]
        [ValidateNotNullOrEmpty()]
        [string[]]$Or,

        [Parameter(Mandatory, ParameterSetName="And")]
        [ValidateNotNullOrEmpty()]
        [string[]]$And
    )
    Process {
        if ($PSCmdlet.ParameterSetName -eq "Name") {
            $Filter = @()

            foreach ($Prop In $PropertyValue) {

                If ([bool]($Prop -as [double]) -and (-not($Search.IsPresent))) {
                    $Filter += "($PropertyName = $Prop)"
                } else {
                    If ($Search.IsPresent) {
                        $Operation = "LIKE"
                        $PropValue = $Prop -replace "\*", "%"
                    } Else {
                        $Operation = "="
                        $PropValue = $Prop
                    }

                    $Filter += "($Propertyname $Operation '$PropValue')"
                }
            }

            $Result = Get-WQLFilterString -Or $Filter
            #if ($Filter.Count -gt 1) {
            #    $Result = "($($Filter -join ' OR '))"
            #} else {
            #    $Result = $Filter
            #}
        } elseif ($PSCmdlet.ParameterSetName -eq "Or") {
            if ($Or.Count -gt 1) {
                $Result = "($($Or -join ' OR '))"
            } else {
                $Result = $Or
            }
        } elseif ($PSCmdlet.ParameterSetName -eq "And") {
            if ($And.Count -gt 1) {
                $Result = "($($And -join ' AND '))"
            } else {
                $Result = $And
            }
        }

        # Fix special characters
        $Result = $Result -replace "(?<!\\)\\(?!\\)", "\\"
        Write-Verbose "Created WQL filter string '$Result'."

        $Result
    }
}

# Used to catch some common errors due to RCP connection issues on slow WAN connections
function Invoke-CimCommand {
    <#
    .SYNOPSIS
        Executes the supplied CIM command.

    .DESCRIPTION
        Used as a wrapper around all common CIM based PowerShell commands to catch common issues.
        Primarily to catch a common RPC error (0X800706bf) on high latency/small bandwidth WAN connections.

    .EXAMPLE
        Invoke-CimCommand {Get-CimInstance -ClassName "Win32_OperatingSystem"}
        Returns an Instance of the "Win32_OperatingSystem" WMI class

    .NOTES

    #>
    [CmdLetBinding()]
    Param(
        # Specifies the CIM based Command that shall be executed
        [Parameter(Mandatory)]
        [scriptblock]$Command
    )

    Process {
        $RetryCount = 0
        Do {
            $Retry = $false

            Try {
                & $Command
            } Catch {
                If ($null -ne $_.Exception) {
                    If (($_.Exception.HResult -eq -2147023169 ) -or ($_.Exception.ErrorData.error_Code -eq 2147944127)) {
                        If ($RetryCount -ge 3) {
                            $Retry = $false
                        } Else {
                            $RetryCount += 1
                            $Retry = $true
                            Write-Verbose "CIM/WMI command failed with Error 2147944127 (HRESULT 0x800706bf)."
                            Write-Verbose "Common RPC error, retry on default. Current retry count $RetryCount"
                        }
                    } Else {
                        Throw $_.Exception
                    }
                } Else {
                    Throw
                }
            }
        } While ($Retry)
    }
}


function Test-CMConnection {
    <#
    .SYNOPSIS
        Validates that a ConfigMgr connection has been created.

    .DESCRIPTION
        Validates that a ConfigMgr connection has been created. If not, a new Connection will be created.

    .EXAMPLE
        Get-WQLFilterString


    .NOTES

    #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSAvoidGlobalVars", "")]
    Param()
    if ( ([string]::IsNullOrWhiteSpace($global:CMProviderServer)) -or
            ([string]::IsNullOrWhiteSpace($global:CMSiteCode)) -or
            ([string]::IsNullOrWhiteSpace($global:CMNamespace)) -or
            ($null -eq $global:CMSession)) {

        New-CMConnection
        $true
    } else {
        $true
    }
}

## PUBLIC MODULE FUNCTIONS AND DATA ##

function Get-CMInstance {
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding()]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSAvoidUsingWMICmdlet", "")]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSAvoidGlobalVars", "")]
    PARAM (
        # Specifies the ConfigMgr WMI provider Class Name
        [Parameter(Mandatory,ValueFromPipeline,ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias("Class")]
        [string]$ClassName,

        # Specifies the Where clause to filter the specified ConfigMgr WMI provider class.
        # If no filter is supplied, all objects will be returned.
        [Parameter(ValueFromPipelineByPropertyName)]
        [string]$Filter,

        # Specifies if the lazy properties shall be fetched as well.
        # On default, lazy properties won't be included in the result.
        [Alias("Lazy")]
        [switch]$IncludeLazy
    )

    Process {
        # Ensure ConfigMgr Provider information is available
        If (Test-CMConnection) {

            If ($Filter.Contains(" JOIN ")) {
                Write-Verbose "Fall back to WMI cmdlets"
                $WMIParams = @{
                    ComputerName = $global:CMProviderServer
                    Namespace = $CMNamespace
                    Class = $ClassName
                    Filter = $Filter
                }
                If ($global:CMCredential -ne [System.Management.Automation.PSCredential]::Empty) {
                    $WMIParams.Credential = $CMCredential
                }
                Invoke-CimCommand {Get-WmiObject @WMIParams -ErrorAction Stop}
            } Else {
                $InstanceParams = @{
                    CimSession = $global:CMSession
                    Namespace = $global:CMNamespace
                    ClassName = $ClassName
                    ErrorAction = "Stop"
                }

                If ($Filter -ne "") { $InstanceParams.Filter = $Filter }

                $Result = Invoke-CimCommand {Get-CimInstance @InstanceParams}

                If ($IncludeLazy.IsPresent) {
                    $Result = Invoke-CimCommand {$Result | Get-CimInstance -ErrorAction Stop}
                }

                $Result
            }
        }
    }
}


function Get-CMPackage {
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding(DefaultParameterSetName="ID")]
    PARAM (
        # Specifies the PackageID
        [Parameter(Mandatory, ParameterSetName="ID",ValueFromPipeline,ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias("PackageID")]
        [string]$ID,

        # Specifies the Package Name
        # If Search is set, the name can include the default WQL placeholders [],^,% and _
        [Parameter(Mandatory, ParameterSetName="Name",ValueFromPipelineByPropertyName)]
        [Alias("PackageName")]
        [string[]]$Name,

        # Specifies if Name contains a search string
        [Parameter(ParameterSetName="Name")]
        [switch]$Search,

        # Specifies the Folder ID
        [Alias("FolderID", "Folder")]
        [string]$ParentID,

        # Specifies the CIID of assigned content.
        [Parameter(Mandatory,ParameterSetName="CIID")]
        [string]$CIID,

        # Specifies the Package Type
        [Parameter(Mandatory,ParameterSetName="ID")]
        [Parameter(Mandatory,ParameterSetName="Name")]
        [Parameter(Mandatory,ParameterSetName="CIID")]
        [ValidateSet("Package","DriverPackage","TaskSequencePackage","SoftwareUpdatePackage","DeviceSettingPackage","VirtualApplicationPackage","ImagePackage","BootImagePackage","OperatingSystemInstallPackage","VHDPackage","All")]
        [Alias("PackageType")]
        [string]$Type,

        # Specifies a custom filter to use
        [Parameter(Mandatory, ParameterSetName = "Filter")]
        [ValidateNotNullOrEmpty()]
        [string]$Filter
    )

    Process {
        # Prepare filter
        $PackageFilter = @()

        If ($PSCmdlet.ParameterSetName -eq "ID") {
            $PackageFilter += Get-WQLFilterString -PropertyName "PackageID" -PropertyValue $ID
        } ElseIf ($PSCmdlet.ParameterSetName -eq "Filter") {
            $PackageFilter += $Filter
        } ElseIf ($PSCmdlet.ParameterSetName -eq "CIID") {
            $PackageFilter += "PackageID IN (SELECT PackageID FROM SMS_PackageToContent WHERE CI_ID = '$CIID')"
        } Else {
            $PackageFilter += Get-WQLFilterString -PropertyName "Name" -PropertyValue $Name -Search:($Search.IsPresent)

            If (-not([string]::IsNullOrEmpty($ParentID))) {
                $PackageFilter += "(PackageID IN (SELECT InstanceKey FROM SMS_ObjectContainerItem WHERE ContainerNodeID = $ParentID))"
            }
        }

        # Evaluate Package Type
        Switch ($Type){
            "Package" {$ClassName = "SMS_Package"}
            "DriverPackage" {$ClassName = "SMS_DriverPackage"}
            "TaskSequencePackage" {$ClassName = "SMS_TaskSequencePackage"}
            "SoftwareUpdatePackage" {$ClassName = "SMS_SoftwareUpdatePackage"}
            "DeviceSettingPackage" {$ClassName = "SMS_DeviceSettingPackage"}
            "VirtualApplicationPackage" {$ClassName = "SMS_Package"; $PackageFilter += "(PackageType = 7)"}
            "ImagePackage" {$ClassName = "SMS_ImagePackage"}
            "BootImagePackage" {$ClassName = "SMS_BootImagePackage"}
            "OperatingSystemInstallPackage" {$ClassName = "SMS_OperatingSystemInstallPackage"}
            "VHDPackage" {$ClassName = "SMS_VHDPackage"}
            "All" {$ClassName = "SMS_PackageBaseClass"}
        }

        $Filter = "($($PackageFilter -join ' AND '))"
        Write-Verbose "Get Package(s) by filter $Filter"
        Get-CMInstance -ClassName $ClassName -Filter $Filter
    }
}


function Get-CMUserDeviceAffinity{
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding(DefaultParameterSetName="ResourceID")]
    PARAM (
        # Specifies the Relationship ID
        [Parameter(Mandatory, ParameterSetName="ID",ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias("RelationshipResourceID")]
        [string[]]$ID,

        # Specifies the DeviceID (ResourceID)
        [Parameter(Mandatory, ParameterSetName="ResourceID",ValueFromPipeline,ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias("DeviceID")]
        [string[]]$ResourceID,

        # Specifies the Device name
        # If Search is set, the name can include the default WQL placeholders [],^,% and _
        [Parameter(ParameterSetName="Name",ValueFromPipelineByPropertyName)]
        [Alias("DeviceName")]
        [string[]]$ResourceName,

        # Specifies the User name
        # If Search is set, the name can include the default WQL placeholders [],^,% and _
        [Parameter(ParameterSetName="Name",ValueFromPipelineByPropertyName)]
        [string[]]$UserName,

        # Specifies if Name contains a search string
        [Parameter(ParameterSetName="Name")]
        [switch]$Search,

        # Specifies the Affinity Source
        [Parameter(ParameterSetName="ID")]
        [Parameter(ParameterSetName="ResourceID")]
        [Parameter(ParameterSetName="Name")]
        [ValidateSet("SoftwareCatalog","Administrator","User","UsageAgent","DeviceManagement","OSD","FastInstall","ExchangeServerConnector")]
        [string]$Source
    )

    Process {
        # Prepare filter
        $TempFilter = @()

        If (-Not([string]::IsNullOrEmpty($Source))) {
            Switch ($Source){
                "SoftwareCatalog" {$SourceID = "1"}
                "Administrator" {$SourceID = "2"}
                "User" {$SourceID = "3"}
                "UsageAgent" {$SourceID = "4"}
                "DeviceManagement" {$SourceID = "5"}
                "OSD" {$SourceID = "6"}
                "FastInstall" {$SourceID = "7"}
                "ExchangeServerConnector" {$SourceID = "8"}
            }

            if ($SourceID -gt 0) {
                $TempFilter += Get-WQLFilterString -PropertyName "Sources" -PropertyValue $SourceID
            }
        }

        If ($PSCmdlet.ParameterSetName -eq "ID") {
            $TempFilter += Get-WQLFilterString -PropertyName "RelationshipResourceID" -PropertyValue $ID
        } ElseIf ($PSCmdlet.ParameterSetName -eq "ResourceID") {
            $TempFilter += Get-WQLFilterString -PropertyName "ResourceID" -PropertyValue $ResourceID
        } ElseIf ($PSCmdlet.ParameterSetName -eq "Name") {
            if ($ResourceName.Count -gt 0) {
                $TempFilter += Get-WQLFilterString -PropertyName "ResourceName" -PropertyValue $ResourceName -Search:($Search.IsPresent)
            }
            if ($UserName.Count -gt 0) {
                $TempFilter += Get-WQLFilterString -PropertyName "UniqueUserName" -PropertyValue $UserName -Search:($Search.IsPresent)
            }
        } Else {
            Throw
        }

        $Filter = Get-WQLFilterString -And $TempFilter

        Write-Verbose "Get UserDeviceAffinities by filter $Filter"
        Get-CMInstance -ClassName "SMS_UserMachineRelationship" -Filter $Filter
    }
}


function Invoke-CMMethod {
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding(SupportsShouldProcess, DefaultParameterSetName="ClassName")]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSAvoidGlobalVars", "")]
    PARAM (
        # Specifies the ConfigMgr WMI provider Class Name
        # Needs to be supplied for static class methods
        [Parameter(Mandatory,ParameterSetName="ClassName")]
        [ValidateNotNullOrEmpty()]
        [string]$ClassName,

        # Specifies the ConfigMgr WMI provider object
        # Needs to be supplied for instance methods
        [Parameter(Mandatory,ParameterSetName="ClassInstance")]
        [ValidateNotNullOrEmpty()]
        [Alias("ClassInstance")]
        [object]$InputObject,

        # Specifies the Method Name
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$MethodName,

        # Specifies the Arguments to be supplied to the method.
        # Should be a hashtable with key/name pairs.
        [hashtable]$Arguments,

        # If set, ReturnValue will not be evaluated
        # Usefull if ReturnValue does not indicated successfull execution
        [switch]$SkipValidation
    )

    Process {
        If ($PSCmdlet.ShouldProcess("$CMProviderServer", "Invoke $MethodName")) {
            # Ensure ConfigMgr Provider information is available
            If (Test-CMConnection) {
                    $Params = @{
                        MethodName = $MethodName
                        Arguments = $Arguments
                        ErrorAction = "Stop"
                    }

                    If ($PSCmdlet.ParameterSetName -eq "ClassInstance") {
                        $Params.InputObject = $InputObject
                    } Else {
                        $Params.CimSession = $Global:CMSession
                        $Params.Namespace = $Global:CMNamespace
                        $Params.ClassName = $ClassName
                    }

                    $Result = Invoke-CimCommand {Invoke-CimMethod @Params}

                    If ((!($SkipValidation.IsPresent)) -and ($null -ne $Result)) {
                        If ($Result.ReturnValue -eq 0) {
                            Write-Verbose "Successfully invoked $MethodName on $CMProviderServer."
                        } Else {
                            Write-Verbose "Failed to invoked $MethodName on $CMProviderServer. ReturnValue: $($Result.ReturnValue)"
                        }
                    }

                Return $Result
            }
        }
    }
}


function New-CMConnection {
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding()]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSAvoidGlobalVars", "")]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseShouldProcessForStateChangingFunctions", "")]
    PARAM (
        # Specifies the ConfigMgr Provider Server name.
        # If no value is specified, the script assumes to be executed on the Site Server.
        [Alias("ServerName", "Name", "SiteServer" ,"ProviderServer")]
        [string]$ProviderServerName = $env:COMPUTERNAME,

        # Specifies the ConfigMgr provider Site Code.
        # If no value is specified, the script will evaluate it from the Site Server.
        [string]$SiteCode,

        # Specifies the Credentials to connect to the Provider Server.
        [PSCredential]
        [System.Management.Automation.Credential()]$Credential = [System.Management.Automation.PSCredential]::Empty
    )

    Process {
        # Get or Create session object to connect to currently provided Providerservername
        # Ensure processing stops if it fails to create a session
        $SessionParams = @{
            ErrorAction = "Stop"
            ComputerName = $ProviderServerName
        }

        if ($PSBoundParameters["Credential"]) {
            $SessionParams.Credential = $Credential
        }

        $CMSession = Get-CMSession @SessionParams

        # Get Provider location
        If ($null -ne $CMSession) {
            $ProviderLocation = $null
            If ($SiteCode -eq $null -or $SiteCode -eq "") {
                Write-Verbose "Get provider location for default site on server $ProviderServerName"
                $ProviderLocation = Invoke-CimCommand {Get-CimInstance -CimSession $CMSession -Namespace "root\sms" -ClassName SMS_ProviderLocation -Filter "ProviderForLocalSite = true" -ErrorAction Stop}
            } Else {
                Write-Verbose "Get provider location for site $SiteCode on server $ProviderServerName"
                $ProviderLocation = Invoke-CimCommand {Get-CimInstance -CimSession $CMSession -Namespace "root\sms" -ClassName SMS_ProviderLocation -Filter "SiteCode = '$SiteCode'" -ErrorAction Stop}
            }

            If ($null -ne $ProviderLocation) {
                # Split up the namespace path
                $Parts = $ProviderLocation.NamespacePath -split "\\", 4
                Write-Verbose "Provider is located on $($ProviderLocation.Machine) in namespace $($Parts[3])"

                # Set Script variables used by ConfigMgr related functions
                $global:CMProviderServer = $ProviderLocation.Machine
                $global:CMNamespace = $Parts[3]
                $global:CMSiteCode = $ProviderLocation.SiteCode
                $global:CMCredential = $Credential

                # Create and store session if necessary
                If ($global:CMProviderServer -ne $ProviderServerName) {
                    $SessionParams.ComputerName = $global:CMProviderServer
                    $CMSession = Get-CMSession @SessionParams
                }

                If ($null -eq $CMSession) {
                    Throw "Unable to establish CIM session to $global:CMProviderServer"
                } Else {
                    $global:CMSession = $CMSession
                }
            } Else {
                # Clear global variables
                $global:CMProviderServer = [string]::Empty
                $global:CMNamespace = [string]::Empty
                $global:CMSiteCode = [string]::Empty
                $global:CMCredential = $null

                Throw "Unable to connect to specified provider"
            }
        } Else {
            # Clear global variables
            $global:CMProviderServer = [string]::Empty
            $global:CMNamespace = [string]::Empty
            $global:CMSiteCode = [string]::Empty
            $global:CMCredential = $null

            Throw "Unable to create CIM session to $ProviderServerName"
        }
    }
}


function New-CMInstance {
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding(SupportsShouldProcess)]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseDeclaredVarsMoreThanAssignments", "")]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSAvoidGlobalVars", "")]
    PARAM (
        # Specifies the ConfigMgr WMI provider Class Name
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$ClassName,

        # Specifies the properties to be supplied to the new object
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [hashtable]$Property,

        # Set EnforceWMI to enforce the deprecated WMI cmdlets
        # still required for e.g. embedded classes without key as they need to be handled differently
        #[switch]$EnforceWMI,

        # Specifies if the new instance shall be created on the client only.
        # Will be used for embedded classes without key property
        [switch]$ClientOnly
    )

    Process {
        # Ensure ConfigMgr Provider information is available
        If (Test-CMConnection) {
            $PropertyString = ($Property.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join "; "
            Write-Debug "Create new $ClassName object. Properties: $PropertyString"

            # TODO: Still required?
            # If ($EnforceWMI) {
            #     $NewCMObject = New-CMWMIInstance -ClassName $ClassName

            #     If ($null -ne $NewCMObject) {
            #         #try to update supplied arguments
            #         Try {
            #             Write-Debug "Add properties to WMI class"
            #             $Property.GetEnumerator() | ForEach-Object {
            #                 $Key = $_.Key
            #                 $Value = $_.Value
            #                 Write-Debug "$Key : $Value"
            #                 $NewCMObject[$Key] = $Value
            #             }
            #         } Catch {
            #             Write-Error "Unable to update properties on WMI class $ClassName"
            #         }
            #     }
            # } Else {
                $Params = @{
                    Namespace = $Global:CMNamespace
                    ClassName = $ClassName
                    Property = $Property
                    ErrorAction = "Stop"
                }

                If ($ClientOnly.IsPresent) {
                    $Params.ClientOnly = $true
                } Else {
                    $Params.CimSession = $global:CMSession
                }

                If ($PSCmdlet.ShouldProcess("Class: $ClassName", "Call New-CimInstance")) {
                    $NewCMObject = Invoke-CimCommand { New-CimInstance @Params}

                    If ($null -ne $NewCMObject) {
                        # Ensure that properties generated by the WMI provider are udpated
                        $hack = $NewCMObject.PSBase | Select-Object * | Out-Null
                    }
                }
            # }

            Return $NewCMObject
        }
    }
}


function New-CMUserDeviceAffinity{
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding(SupportsShouldProcess)]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSShouldProcess", "")]
    PARAM (
        # Specifies the DeviceID (ResourceID)
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [ValidateRange(1, [uint32]::MaxValue)]
        [Alias("DeviceID")]
        [uint32]$ResourceID,

        # Specifies the User name
        # e.g. "{Domain}\{samaccountname}
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [string]$UserName,

        # Specifies the Package Type
        [ValidateSet("SoftwareCatalog","Administrator","User","UsageAgent","DeviceManagement","OSD","FastInstall","ExchangeServerConnector")]
        [ValidateNotNullOrEmpty()]
        [string]$Source = "Administrator",

        # Specifies if the Type property should be set for the relationship
        [switch]$NoType
    )

    Process {
         Switch ($Source){
            "SoftwareCatalog" {$SourceID = 1}
            "Administrator" {$SourceID = 2}
            "User" {$SourceID = 3}
            "UsageAgent" {$SourceID = 4}
            "DeviceManagement" {$SourceID = 5}
            "OSD" {$SourceID = 6}
            "FastInstall" {$SourceID = 7}
            "ExchangeServerConnector" {$SourceID = 8}
        }

        $MethodArgs = @{
            MachineResourceID = [uint32]$ResourceID
            UserAccountName = $UserName
            SourceID = [uint32]$SourceID
        }

        if (-not($NoType.IsPresent)) { $MethodArgs.TypeID = [uint32]1 }

        Invoke-CMMethod -ClassName "SMS_UserMachineRelationship" -MethodName "CreateRelationship" -Arguments $MethodArgs
    }
}


function Remove-CMInstance {
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding(SupportsShouldProcess,DefaultParameterSetName="ClassInstance")]
    PARAM (
        # Specifies the ConfigMgr WMI provider Class Name
        [Parameter(Mandatory,ParameterSetName="ClassName",ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [string]$ClassName,

        # Specifies the Filter
        [Parameter(Mandatory,ParameterSetName="ClassName",ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [string]$Filter,

        # Specifies the ConfigMgr WMI provider object
        [Parameter(Mandatory,ParameterSetName="ClassInstance",ValueFromPipeline,ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias("ClassInstance")]
        [object]$InputObject
    )

    Process {
        # Ensure ConfigMgr Provider information is available
        if (Test-CMConnection) {
            if ($PSCmdlet.ParameterSetName -eq "ClassName") {
                $InputObject = Get-CMInstance -Class $ClassName -Filter $Filter
            }

            if ($null -ne $InputObject) {
                $Params = @{
                    InputObject = $InputObject
                    ErrorAction = "Stop"
                }

                Invoke-CimCommand {Remove-CimInstance @Params}
            }
        }
    }
}


function Set-CMInstance {
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding(SupportsShouldProcess,DefaultParameterSetName="Instance")]
    PARAM (
        # Specifies the ConfigMgr WMI provider Class Name
        [Parameter(Mandatory,ParameterSetName="Name")]
        [ValidateNotNullOrEmpty()]
        [Alias("Class")]
        [string]$ClassName,

        # Specifies the Filter
        [Parameter(Mandatory,ParameterSetName="Name")]
        [ValidateNotNullOrEmpty()]
        [string]$Filter,

        # Specifies the ConfigMgr WMI provider object
        [Parameter(Mandatory,ParameterSetName="Instance",ValueFromPipeline,ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias("ClassInstance")]
        [object]$InputObject,

        # Specifies the properties to be set on the instance.
        # Should be a hashtable with key/name pairs.
        [Parameter(Mandatory, ParameterSetName="Name")]
        [Parameter(Mandatory, ParameterSetName="Instance")]
        [ValidateNotNullOrEmpty()]
        [hashtable]$Property,

        # Specifies if updated object shall be returned
        [switch]$PassThru
    )

    Process {
        # Ensure ConfigMgr Provider information is available
        If (Test-CMConnection) {
            If ($PSCmdlet.ParameterSetName -eq "Name") {
                $InputObject = Get-CMInstance -ClassName $ClassName -Filter $Filter
            }

            If ($null -ne $InputObject) {
                $Params = @{
                    InputObject = $InputObject
                    Property = $Property
                    ErrorAction = "Stop"
                }

                If ($PassThru.IsPresent) {$Params.PassThru = $PassThru}

                Invoke-CimCommand {Set-CimInstance @Params}
            }
        }
    }
}




function Write-Log {
    <#
    .EXTERNALHELP ConfigMgr-help.xml
    #>
    [CmdletBinding()]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSAvoidGlobalVars", "")]
    param (
        # Defines the content that should be added to the log file.
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias("LogContent")]
        [string]$Message,

        # The path to the log file to which the Message shall be written.
        # Path and file will be created if it does not exist.
        # If omitted function will use the $LogPath variable defined on script or global level.
        # If that isn't set as well, function will fail
        [Alias('LogPath')]
        [string]$Path,

        # Defines the criticality of the log information being written to the log.
        # Can be any of Error, Warning, Informational
        # Default is Info
        [ValidateSet("Error","Warning","Info")]
        [Alias("Level")]
        [string]$Severity="Info",

        # Defines if the Message should be passed through the pipeline.
        # Severity will be mapped to the corresponding Write-Verbose, Write-Warning
        # or Write-Error functions
        [Switch]$PassThru,

        # Defines if the message should be written as plain text message.
        # On default, System Center Configuration Manager log format is used.
        [Alias('AsText','a')]
        [Switch] $AsPlainText
    )

    begin {
        # Evaluate caller information
        $Caller = (Get-PSCallStack)[1]
        $Component = $Caller.Command
        $Source = $Caller.Location

        # Get Logpath from script/global level if not supplied explicitly
        # If no logpath is specified at all, write to current Temp folder
        if ([string]::IsNullOrEmpty($Path)) {
            $Path = $Script:LogPath
            if ([string]::IsNullOrEmpty($Path)) {
                $Path = $Global:LogPath
                if ([string]::IsNullOrEmpty($Path)) {
                    if ([string]::IsNullOrEmpty($Source)) {
                        $LogName = [guid]::NewGuid().ToString()
                    } else {
                        if ($Source -like "*.*") {
                            $LogName = $Source.Split('\.')[0]
                        } else {
                            $LogName = $Source
                        }
                    }
                    $Path = Join-Path -Path $Env:TEMP -ChildPath "$LogName.log"
                }
            }
        }
    }

    process {
        # Make sure file and path exist
        if (-not(Test-Path $Path)) {
            Write-Verbose "Creating '$Path'."
            New-Item $Path -Force -ItemType File -ErrorAction SilentlyContinue | Out-Null
        }

        if ($AsPlainText) {
            $FormattedDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            $LogText = "$FormattedDate [$($Severity.ToUpper())] - $Message"
        } else {
            # Prepare ConfigMgr Log entry
            switch ($Severity) {
                "Error" { $Sev = 3 }
                "Warning" { $Sev = 2 }
                "Info" { $Sev = 1 }
            }

            # Get Timezone Bias to allign log entries through different timezones
            if ($null -eq $Script:TimezoneBias) {
                [int] $Script:TimezoneBias = Get-CimInstance -ClassName Win32_TimeZone -ErrorAction SilentlyContinue -Verbose:$false | Select-Object -ExpandProperty Bias
            }

            $Date = Get-Date -Format "MM-dd-yyyy"
            $Time = Get-Date -Format "HH:mm:ss.fff"
            $TimeString = "$Time$script:TimezoneBias"

            $LogText = "<![LOG[$Message]LOG]!><time=`"$TimeString`" date=`"$Date`" component=`"$Component`" context=`"`" type=`"$Sev`" thread=`"0`" file=`"$Source`">"
        }

        # Write log entry to $Path
        $LogText | Out-File -FilePath $Path -Append -Force -Encoding default -NoClobber -ErrorAction SilentlyContinue

        # forward to pipeline
        if ($PassThru.IsPresent) {
            switch ($Severity) {
                "Error" { Write-Error $Message }
                "Warning" { Write-Warning $Message }
                "Info" { Write-Verbose $Message }
            }
        }
    }
}



